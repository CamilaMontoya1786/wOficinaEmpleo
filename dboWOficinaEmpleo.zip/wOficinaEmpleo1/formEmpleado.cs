﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wOficinaEmpleo1
{
    public partial class formEmpleado : Form
    {

        public formEmpleado()
        {
            InitializeComponent();
        }
        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                //evento salir
                this.Close();
            }

        }








        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void btnLimpiar_Click_1(object sender, EventArgs e)
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtDocumento.Text = "";
            txtEstudios.Text = " ";
            txtFecha.Text = "";
            txtTipoDocumento.Text = "   ";
            txtTituloAcademico.Text = "";
            dtgEmpleado.DataSource = "";

        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();
                clsConexionSql consulta = new clsConexionSql();
                dtgEmpleado.DataSource = consulta.consultarDato();

            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al consultar el dato" + ex);
            }
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionSql insertar = new clsConexionSql(txtNombre.Text, txtApellido.Text, Convert.ToInt32(txtDocumento.Text), Convert.ToDateTime(txtFecha.Text), txtEstudios.Text, txtTituloAcademico.Text, txtTipoDocumento.Text); 
                insertar.insertarDato();

                MessageBox.Show("El dato ha sido ingresado");

            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al ingresar el dato" + ex);

            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionSql cls = new clsConexionSql(txtNombre.Text, txtApellido.Text, Convert.ToInt32(txtDocumento.Text), Convert.ToDateTime(txtFecha.Text), txtEstudios.Text, txtTituloAcademico.Text, txtTipoDocumento.Text);

                cls.modificarDato();
                MessageBox.Show("Sus datos han sido modificados exitosamente.");

                dtgEmpleado.DataSource = cls.consultarDato();



            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al modificar dato"+ ex);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionSql cls = new clsConexionSql();
                cls.eliminarDato(Convert.ToInt32(txtDocumento.Text));
                dtgEmpleado.DataSource = cls.consultarDato();

            }
            catch (Exception)
            {

                throw;
            }
        }

        private void btnRegresar_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

      
        private void dtgEmpleado_MouseClick(object sender, MouseEventArgs e)
        {
            //Va a tomar la tabla como un array y va a seleccionar todo desde la fila cero y me lo evalue como string
            txtNombre.Text = dtgEmpleado.SelectedRows[0].Cells[0].Value.ToString();
            txtApellido.Text = dtgEmpleado.SelectedRows[0].Cells[1].Value.ToString();
            txtDocumento.Text = dtgEmpleado.SelectedRows[0].Cells[2].Value.ToString();
            txtFecha.Text = dtgEmpleado.SelectedRows[0].Cells[3].Value.ToString();
            txtEstudios.Text = dtgEmpleado.SelectedRows[0].Cells[4].Value.ToString();
            txtTituloAcademico.Text = dtgEmpleado.SelectedRows[0].Cells[5].Value.ToString();
            txtTipoDocumento.Text = dtgEmpleado.SelectedRows[0].Cells[6].Value.ToString();
        }

        private void formEmpleado_Load(object sender, EventArgs e)
        {

        }
    }
}

