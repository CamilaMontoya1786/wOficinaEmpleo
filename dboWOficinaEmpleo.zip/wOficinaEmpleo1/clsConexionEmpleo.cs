﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wOficinaEmpleo1
{
    internal class clsConexionEmpleo
    {

       

            public int intCodigoEmpleo { get; set; }
            public string strNombreDelEmpleo { get; set; }
            public string strDescripcion { get; set; }
            public int intSalario { get; set; }
            public int intAñosExperiencia { get; set; }

             public clsConexionEmpleo()
            {
            }

             public clsConexionEmpleo(int intCodigoEmpleo, string strNombreDelEmpleo, string strDescripcion, int intSalario, int intAñosExperiencia)
            {
                this.intCodigoEmpleo = intCodigoEmpleo;
                this.strNombreDelEmpleo = strNombreDelEmpleo;
                this.strDescripcion = strDescripcion;
                this.intSalario = intSalario;
                this.intAñosExperiencia = intAñosExperiencia;
            }
        



            //Constructor


            //Metodo para insertar los datos 
            public bool insertarDatoEmpleo()
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                string insertar = "insert into  tblEmpleo values (@intCodigoEmpleo ,@strNombreDelEmpleo ,@strDescripcion, @intSalario, @intAñosExperiencia)";
                SqlCommand sql = new SqlCommand(insertar, conexion);
                sql.Parameters.AddWithValue("@intCodigoEmpleo", this.intCodigoEmpleo);
                sql.Parameters.AddWithValue("@strNombreDelEmpleo", this.strNombreDelEmpleo);
                sql.Parameters.AddWithValue("@strDescripcion", this.strDescripcion);
                sql.Parameters.AddWithValue("@intSalario", this.intSalario);
                sql.Parameters.AddWithValue("@intAñosExperiencia", this.intAñosExperiencia);
                sql.ExecuteNonQuery();
                return true;
            }


            public DataTable consultarDatoEmpleo(int intCodigoEmpleo)
        
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

               
                DataTable dt = new DataTable();
                this.intCodigoEmpleo = intCodigoEmpleo;
                string consulta = "select * from tblEmpleo where intCodigoEmpleo = @intCodigoEmpleo";
                SqlCommand cmd = new SqlCommand(consulta, conexion);
                cmd.Parameters.AddWithValue("@intCodigoEmpleo", this.intCodigoEmpleo);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;
            }


            public bool eliminarDatoEmpleo(int intCodigoEmpleo)
            {
                try
                {
                    SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                    conexion.Open();

                    this.intCodigoEmpleo = intCodigoEmpleo;
                    string eliminar = "delete tblEmpleo where intCodigoEmpleo = @intCodigoEmpleo";
                    SqlCommand sql = new SqlCommand(eliminar, conexion);
                    sql.Parameters.AddWithValue("@intCodigoEmpleo", this.intCodigoEmpleo);
                    sql.ExecuteNonQuery();
                    return true;

                }
                catch (Exception)
                {

                    throw;
                }

            }

            public bool modificarDatoEmpleo(int intCodigoEmpleo)
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();
                string insertar = "update tblEmpleo set intCodigoEmpleo = @intCodigoEmpleo, strNombreDelEmpleo = @strNombreDelEmpleo, strDescripcion = @strDescripcion, intSalario = @intSalario, intAñosExperiencia = @intAñosExperiencia where intCodigoEmpleo = @intCodigoEmpleo;";
                SqlCommand sql = new SqlCommand(insertar, conexion);
                sql.Parameters.AddWithValue("@intCodigoEmpleo", this.intCodigoEmpleo);
                sql.Parameters.AddWithValue("@strNombreDelEmpleo", this.strNombreDelEmpleo);
                sql.Parameters.AddWithValue("@strDescripcion", this.strDescripcion);
                sql.Parameters.AddWithValue("@intSalario", this.intSalario);
                sql.Parameters.AddWithValue("@intAñosExperiencia", this.intAñosExperiencia);


                sql.ExecuteNonQuery();


                return true;
            }



            public DataTable seleccionarDatoEmpleo()
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                this.intCodigoEmpleo = intCodigoEmpleo;
                DataTable dt = new DataTable();
                string seleccionar = "select * from tblEmpleo where intCodigoEmpleo = @intCodigoEmpleo";
                SqlCommand cmd = new SqlCommand(seleccionar, conexion);
                cmd.Parameters.AddWithValue("@intCodigoEmpleo", this.intCodigoEmpleo);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                return dt;







            }
        }
    
}
