﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wOficinaEmpleo1
{
    internal class clsConexionSql
    {

        public string strNombre { get; set; }
        public string strApellido { get; set; }
        public string strTipoDocumento { get; set; }
        public int intDocumento { get; set; }
        public DateTime datFechaDeNacimiento { get; set; }
        public string strNivelEstudio { get; set; }
        public string strTituloAcademico { get; set; }

        public clsConexionSql()
        {
        }




        public clsConexionSql(string strNombre, string strApellido, int intDocumento, DateTime datFechaDeNacimiento, string strNivelEstudio, string strTituloAcademico, string strTipoDocumento)
        {
            this.strNombre = strNombre;
            this.strApellido = strApellido;
            this.intDocumento = intDocumento;
            this.datFechaDeNacimiento = datFechaDeNacimiento;
            this.strNivelEstudio = strNivelEstudio;
            this.strTituloAcademico = strTituloAcademico;
            this.strTipoDocumento = strTipoDocumento;
        }

       



        //Metodo para insertar los datos 
        public bool insertarDato()
        {
            SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
            conexion.Open();
            string insertar = "insert into tblEmpleado values(@strNombre, @strApellido,  @intDocumento, @datFechaDeNacimiento, @strNivelEstudio, @strTituloAcademico, @strTipoDocumento)";
            SqlCommand sql = new SqlCommand(insertar, conexion);
            sql.Parameters.AddWithValue("@strNombre", this.strNombre);
            sql.Parameters.AddWithValue("@strApellido", this.strApellido);
            sql.Parameters.AddWithValue("@intDocumento", this.intDocumento);
            sql.Parameters.AddWithValue("@datFechaDeNacimiento", this.datFechaDeNacimiento);
            sql.Parameters.AddWithValue("@strNivelEstudio", this.strNivelEstudio);
            sql.Parameters.AddWithValue("@strTituloAcademico", this.strTituloAcademico);
            sql.Parameters.AddWithValue("@strTipoDocumento", this.strTipoDocumento);

            sql.ExecuteNonQuery();
            return true;
        }


        public DataTable consultarDato()
        {
            SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
            conexion.Open();

            DataTable dt = new DataTable();
            string consulta = "select * from tblEmpleado";
            SqlCommand cmd = new SqlCommand(consulta, conexion);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;
        }


        public bool eliminarDato(int intDocumento)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                this.intDocumento = intDocumento;
                string eliminar = "delete tblEmpleado where intDocumento= @intDocumento";
                SqlCommand sql = new SqlCommand(eliminar, conexion);
                sql.Parameters.AddWithValue("@intDocumento", this.intDocumento);
                sql.ExecuteNonQuery();
                return true;

            }
            catch (Exception)
            {

                throw;
            }

        }


        //Falta revisar este modificar igual que el de la otra clase, tienen el mismo error
        public bool modificarDato()
        {
            SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
            conexion.Open();
            string insertar = "UPDATE tblEmpleado SET strNombre = @strNombre, strApellido = @strApellido, intDocumento = @intDocumento, datFechaDeNacimiento = @datFechaDeNacimiento, strNivelEstudio = @strNivelEstudio, strTituloAcademico = @strTituloAcademico, strTipoDocumento = @strTipoDocumento where intDocumento = @intDocumento;";
            SqlCommand sql = new SqlCommand(insertar, conexion);
            sql.Parameters.AddWithValue("@strNombre", this.strNombre);
            sql.Parameters.AddWithValue("@strApellido", this.strApellido);
            sql.Parameters.AddWithValue("@intDocumento", this.intDocumento);
            sql.Parameters.AddWithValue("@datFechaDeNacimiento", this.datFechaDeNacimiento);
            sql.Parameters.AddWithValue("@strNivelEstudio", this.strNivelEstudio);
            sql.Parameters.AddWithValue("@strTituloAcademico", this.strTituloAcademico);
            sql.Parameters.AddWithValue("@strTipoDocumento", this.strTipoDocumento);


            sql.ExecuteNonQuery();


            return true;
        }



        public DataTable seleccionarDato()
        {
            SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
            conexion.Open();

            this.intDocumento = intDocumento;
            DataTable dt = new DataTable();
            string seleccionar = "select * from tblEmpleado where intDocumento = @intDocumento";
            SqlCommand cmd = new SqlCommand(seleccionar, conexion);
            cmd.Parameters.AddWithValue("@intDocumento", this.intDocumento);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;







        }
    }
}
