﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wOficinaEmpleo1
{
    public partial class formBuscarEmpleo : Form
    {
        public formBuscarEmpleo()
        {
            InitializeComponent();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionEmpleo insertar = new clsConexionEmpleo(Convert.ToInt32(txtCodigo.Text), txtNombreEmpleo.Text, txtDescripcion.Text, Convert.ToInt32(txtSalario.Text), Convert.ToInt32(txtAñosExperiencia.Text)); 
                insertar.insertarDatoEmpleo();

                MessageBox.Show("El dato ha sido ingresado");



            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al ingresar el dato" + ex);

            }
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionEmpleo consulta = new clsConexionEmpleo();
                dtgEmpleo.DataSource = consulta.consultarDatoEmpleo(Convert.ToInt32(txtCodigo.Text));

              


            }
            catch (Exception ex)
            {

                MessageBox.Show("El dato no puede ser ingresado" + ex);
            }
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();
                clsConexionEmpleo modificar = new clsConexionEmpleo(Convert.ToInt16(txtCodigo.Text), txtNombreEmpleo.Text, txtDescripcion.Text, Convert.ToInt32(txtSalario.Text), Convert.ToInt32(txtAñosExperiencia.Text)); //Falta colocar el ciorrecto text box

                modificar.modificarDatoEmpleo(Convert.ToInt32(txtCodigo.Text));
                MessageBox.Show("Sus datos han sido modificados exitosamente.");

                dtgEmpleo.DataSource = modificar.consultarDatoEmpleo(Convert.ToInt32(txtCodigo.Text));


            }
            catch (Exception ex)
            {

                MessageBox.Show("Error al modificar dato" + ex);
            }

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection conexion = new SqlConnection("server=LAPTOP-IH6HOANE\\SQLEXPRESS;database=dboOficinaEmpleo; integrated security = true ");
                conexion.Open();

                clsConexionEmpleo cls = new clsConexionEmpleo();
                cls.eliminarDatoEmpleo(Convert.ToInt32(txtCodigo.Text));
               dtgEmpleo.DataSource = cls.consultarDatoEmpleo(Convert.ToInt32(txtCodigo.Text));

            }
            catch (Exception)
            {

                throw;
            }

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtCodigo.Text = "";
            txtDescripcion.Text = "";
            txtNombreEmpleo.Text = "";
            txtSalario.Text = "";
            txtAñosExperiencia.Text = "";
            dtgEmpleo.DataSource = "";

        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtgEmpleo_MouseClick(object sender, MouseEventArgs e)
        {
            //Va a tomar la tabla como un array y va a seleccionar todo desde la fila cero y me lo evalue como string
            txtCodigo.Text =  dtgEmpleo.SelectedRows[0].Cells[0].Value.ToString();
            txtNombreEmpleo.Text = dtgEmpleo.SelectedRows[0].Cells[1].Value.ToString();
            txtDescripcion.Text = dtgEmpleo.SelectedRows[0].Cells[2].Value.ToString();
            txtSalario.Text = dtgEmpleo.SelectedRows[0].Cells[3].Value.ToString();
            txtAñosExperiencia.Text = dtgEmpleo.SelectedRows[0].Cells[4].Value.ToString();


        
        }

        
    }
}
