﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/// INTEGRANTE: Maria Camila Montoya Zapata - Jaider Oquendo Zapata
/// DESCRIPCIÓN:   Conexión a base de datos, formulario MDI
/// FECHA: 16/05/2023

namespace wOficinaEmpleo1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void empleadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            formEmpleado frmEmpleado = new formEmpleado();
            frmEmpleado.MdiParent = this;
            frmEmpleado.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buscarEmpleoToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

            formBuscarEmpleo frmBuscarEmpleo = new formBuscarEmpleo();
            frmBuscarEmpleo.MdiParent = this;
            frmBuscarEmpleo.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
