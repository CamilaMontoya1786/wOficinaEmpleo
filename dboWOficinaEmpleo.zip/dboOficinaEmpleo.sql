create database dboOficinaEmpleo
use dboOficinaEmpleo;

--Para crear tablas 
create table tblEmpleado(
strNombre varchar(20) not null,
strApellido varchar(20) not null,
intDocumento bigint not null,
datFechaDeNacimiento date not null,
strNivelEstudio varchar(20) not null,
strTituloAcademico varchar (20) not null,
strTipoDocumento varchar (20) not null,
primary key (intDocumento));

create table tblEmpleo(
intCodigoEmpleo int not null,
strNombreDelEmpleo varchar(20) not null,
strDescripcion varchar(20) not null,
intSalario int not null,
intA�osExperiencia int not null,
primary key (intCodigoEmpleo));

select *from tblEmpleado;

select * from tblEmpleo;

